﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class Rules : MonoBehaviour {
    public Texture backgroundTexture;
    public string mainMenu;
    string rules = "     Use WASD to move the player. While starting, ball would be in the middle of the field. Players can only score by hitting the ball in charge-bar, but it depends which side they hit. For example: If player blue hit the ball and goals at the opposite side they get one point but if they hit their own side then red team gets the point.";
    void OnGUI(){
        // display background texture
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), backgroundTexture);

        // change color and size
        GUI.color = Color.yellow;
        GUI.skin.button.fontSize = 30;
        GUI.skin.textArea.fontSize = 30;

        GUI.TextArea(new Rect(Screen.width * 0.25f, Screen.height * 0.25f, Screen.width / 2, Screen.height / 2), rules);
        if (GUI.Button(new Rect(Screen.width * 0.75f, Screen.height *.75f, Screen.width / 4, Screen.height / 10), "Return")){
            SceneManager.LoadScene(mainMenu);
        }
    }
}
