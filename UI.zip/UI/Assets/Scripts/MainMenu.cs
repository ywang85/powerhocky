﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour {
    public Texture backgroundTexture;
    public string mainGame, rules;
    void OnGUI(){
        // display background texture
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), backgroundTexture);

        // change font and color
        GUI.color = Color.yellow;
        GUI.skin.button.fontSize = 30;
        // display buttons
        if (GUI.Button(new Rect(Screen.width *0.75f, Screen.height / 4, Screen.width / 4, Screen.height / 10), "Start")){
            SceneManager.LoadScene(mainGame);
        }
        if (GUI.Button(new Rect(Screen.width * 0.75f, Screen.height/4+Screen.height/2, Screen.width / 4, Screen.height / 10), "Exit")){
            Application.Quit();
        }
        if (GUI.Button(new Rect(Screen.width * 0.75f, Screen.height / 2, Screen.width / 4, Screen.height / 10), "Rules")){
            SceneManager.LoadScene(rules);
        }
    }
}
